import React from 'react'
import { assets } from '../assets/assets'

function Contact() {
  return (
    <div>
      <div className='text-center text-2xl pt-10 text-gray-500'>
        <p>Contact <span className='text-gray-700 font-medium'>US</span></p>
      </div>
      <div className="flex flex-col md:flex-row bg-white shadow-lg rounded-lg overflow-hidden p-6 md:p-10 gap-8 max-w-5xl mx-auto">
  <img
    src={assets.contact_image}
    alt="Office"
    className="w-full md:w-1/2 object-cover rounded-lg"
  />
  <div className="flex flex-col justify-center text-gray-700 space-y-4 md:w-1/2">
    <div>
      <p className="text-xl font-semibold mb-1">Our Office</p>
      <p className="text-sm">
        8564 Elm Street <br />
        Springfield, IL 62704 USA
      </p>
    </div>
    <div>
      <p className="text-sm">
        Tel: <span className="font-medium">(555) 184-34523</span> <br />
        Email: <span className="font-medium">support@prescripto.com</span>
      </p>
    </div>
    <div>
      <p className="text-lg font-semibold">Career at Prescripto</p>
      <p className="text-sm">Learn more about our teams and job openings</p>
    </div>
    <button className="mt-4 w-fit bg-blue-600 text-white font-medium px-6 py-2 rounded-full hover:bg-blue-700 transition">
      Explore Now
    </button>
  </div>
</div>

    </div>
  )
}

export default Contact
