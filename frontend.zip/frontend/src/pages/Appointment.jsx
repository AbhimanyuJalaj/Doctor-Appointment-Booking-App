import React, { useContext, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { assets } from '../assets/assets';
import { AppContext } from '../context/AppContext';
import RelatedDoctor from '../components/RelatedDoctor';

function Appointment() {
  const { docId } = useParams();
  const { doctors, currency } = useContext(AppContext);
  const [docInfo, setDocInfo] = useState(null);
  const [docSlot, setDocSlot] = useState([]);
  const [slotIndex, setSlotIndex] = useState(0);
  const [slotTime, setSlotTime] = useState('');
  const daysOfWeek = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

  const getAvailableSlots = async () => {
    setDocSlot([]);
    const today = new Date();

    for (let i = 0; i < 7; i++) {
      let currentDate = new Date(today);
      currentDate.setDate(today.getDate() + i);

      let endTime = new Date(currentDate);
      endTime.setHours(21, 0, 0, 0);

      if (i === 0) {
        const now = new Date();
        currentDate.setHours(now.getHours() >= 10 ? now.getHours() + 1 : 10);
        currentDate.setMinutes(now.getMinutes() > 30 ? 30 : 0);
      } else {
        currentDate.setHours(10);
        currentDate.setMinutes(0);
      }

      let timeSlots = [];
      while (currentDate < endTime) {
        timeSlots.push({
          datetime: new Date(currentDate),
          time: currentDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        });
        currentDate.setMinutes(currentDate.getMinutes() + 30);
      }

      setDocSlot(prev => [...prev, timeSlots]);
    }
  };

  useEffect(() => {
    if (docInfo) getAvailableSlots();
  }, [docInfo]);

  useEffect(() => {
    const doc = doctors.find(doctor => doctor._id === docId);
    setDocInfo(doc);
  }, [doctors, docId]);

  return docInfo && (
    <div className="px-4 sm:px-6 lg:px-8 py-6">
      {/* Doctor Info */}
      <div className="flex flex-col md:flex-row gap-6 items-start mb-6">
        <img
          className="w-full sm:w-64 h-auto rounded border border-gray-300 object-cover bg-blue-100"
          src={docInfo.image}
          alt={docInfo.name}
        />

        <div className="flex-1 border border-gray-300 rounded-lg p-5 bg-white shadow-sm">
          <p className="flex items-center gap-2 text-2xl font-semibold text-gray-900">
            {docInfo.name}
            <img className="w-6" src={assets.verified_icon} alt="Verified" />
          </p>
          <div className="flex flex-wrap items-center gap-2 text-sm mt-2 text-gray-600">
            <p>{docInfo.degree} - {docInfo.speciality}</p>
            <span className="py-0.5 px-2 border text-xs rounded-full">{docInfo.experience}</span>
          </div>

          <div className="mt-4">
            <p className="flex items-center gap-1 font-medium text-gray-800">
              About <img src={assets.info_icon} alt="Info" />
            </p>
            <p className="text-sm text-gray-600 mt-1">{docInfo.about}</p>
          </div>

          <p className="mt-3 text-gray-800 text-sm">
            Doctor fee: <strong>{currency}{docInfo.fees}</strong>
          </p>
        </div>
      </div>

      {/* Booking Slot */}
      <div className="mt-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-2">Booking Slots</h2>

        <div className="flex items-center gap-3 w-full overflow-x-auto scrollbar-hide mb-4">
          {docSlot.length > 0 &&
            docSlot.map((item, pos) => (
              <div
                key={pos}
                className={`min-w-[70px] px-3 py-3 rounded-full text-center cursor-pointer transition 
                ${slotIndex === pos
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-100'
                  }`}
                onClick={() => setSlotIndex(pos)}
              >
                <p className="text-sm font-medium">{item[0] && daysOfWeek[item[0].datetime.getDay()]}</p>
                <p className="text-xs">{item[0] && item[0].datetime.getDate()}</p>
              </div>
            ))}
        </div>

        {/* Time Slots */}
        <div className="flex items-center gap-3 w-full overflow-x-auto scrollbar-hide mb-6">
          {docSlot.length > 0 &&
            docSlot[slotIndex].map((item, pos) => (
              <div
                key={pos}
                onClick={() => setSlotTime(item.time)}
                className={`text-sm px-5 py-2 rounded-full flex-shrink-0 cursor-pointer transition
                ${slotTime === item.time
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-100'
                  }`}
              >
                {item.time.toLowerCase()}
              </div>
            ))}
        </div>

        <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-full shadow transition duration-200">
          Book an Appointment
        </button>
      </div>

      {/* Related Doctors */}
      <div className="mt-10">
        <RelatedDoctor docId={docId} speciality={docInfo.speciality} />
      </div>
    </div>
  );
}

export default Appointment;
