import React from 'react'
import { assets } from '../assets/assets'

function chooseUs(reason,pt){
  return <div className='w-full h-full border px-10 md:px-16 py-8 sm:py-16 flex flex-col gap-5 text-[15px] hover:bg-blue-600 hover:text-white transition-all duration-300 text-gray-600 cursor-pointer'>
      <b>{reason}</b>
      <p>{pt}</p>
  </div>
}

function About() {
  return (
    <div>
      <div className='text-center text-2xl pt-10 text-gray-500'>
        <p>About <span className='text-gray-700 font-medium'>US</span></p>
      </div>
      <div className='flex flex-col md:flex-row gap-12'>
        <img className="w-full md:max-w-[360px]" src = {assets.about_image} alt=""/>
        <div className='px-2 py-4 flex flex-col justify-center text-justify gap-6 md:w-2/4 text-sm text-gray-600'>
          <p>Online doctor consultation has become increasingly important in modern healthcare due to its convenience, accessibility, and time efficiency. It allows patients to connect with qualified medical professionals from the comfort of their homes, eliminating the need for travel and long waiting times. This is especially beneficial for individuals in remote or underserved areas who may have limited access to healthcare facilities. Additionally, online consultations can provide quicker medical advice for non-emergency conditions, support chronic disease management, and reduce the burden on traditional healthcare systems. Overall, it enhances patient care by making medical services more reachable and efficient.</p>
          <p>Prescripto achieves the importance of online doctor consultation by offering a user-friendly platform that connects patients with licensed medical professionals quickly and securely. By eliminating the need for in-person visits, Prescripto makes healthcare more accessible, especially for those in remote areas or with mobility challenges. The platform ensures timely consultations, prescription services, and follow-up care, all from the convenience of a smartphone or computer. With its emphasis on data privacy, verified practitioners, and efficient service delivery, Prescripto not only improves the patient experience but also helps reduce strain on traditional healthcare systems, making quality care more efficient and widespread.</p>
          <b className='text-gray-800'>Our Vision</b>
          <p>To revolutionize healthcare access by becoming the leading digital platform that empowers individuals with seamless, secure, and affordable online medical consultations ensuring that quality healthcare is available to everyone, anytime, anywhere.</p>
        </div>
      </div>

      <div>
        <p className='my-10 text-gray-500'>WHY <span className='text-gray-700 text-semibold'>CHOOSE US</span></p>
        <div className='flex justify-center text-justify flex-col md:flex-row'>
          <div>{chooseUs("Efficiency","Prescripto is designed to streamline the healthcare process by minimizing delays, reducing unnecessary travel, and offering rapid access to medical advice and prescriptions.")}</div>
          <div>{chooseUs("Convenience","This digital-first approach not only improves the speed and ease of healthcare delivery but also optimizes doctor availability and resource utilization, making healthcare more efficient for both patients and providers.")}</div>
          <div>{chooseUs("Personalization","Prescripto offers a highly personalized healthcare experience by tailoring medical consultations and treatment plans to each user’s unique health profile.")}</div>
        </div>
      </div>
      
    </div>
  )
}

export default About
