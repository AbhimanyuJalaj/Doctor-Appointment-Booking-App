import React, { useEffect, useContext, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AppContext } from '../context/AppContext';


function Doctor() {
  const { speciality } = useParams();
  const { doctors } = useContext(AppContext);
  const [filterDoc, setfilterDoc] = useState([]);
  const navigate = useNavigate();

  const applyFilter = () => {
    if (speciality) {
      setfilterDoc(doctors.filter((doc) => doc.speciality === speciality));
    } else {
      setfilterDoc(doctors);
    }
  };

  const menuCss = (s)=>{
    if (speciality === s){
        return "bg-blue-500 text-white px-4 py-2 rounded-full"
    }
    return "cursor-pointer border border-blue-500 text-blue-600 px-4 py-2 rounded-full hover:bg-blue-500 hover:text-white transition-all duration-300";
  }
  useEffect(() => {
    applyFilter();
  }, [doctors, speciality]);

  return (
    <div className="flex flex-col">
      <p>Browse through the specialist doctors</p>

      <div className="flex flex-wrap gap-3 p-4">
        {/* You could dynamically render these specialities too */}
        <p onClick={()=>navigate("/doctors/General physician")} className={menuCss("General physician")}> General Physicians</p>
        <p onClick={()=>navigate("/doctors/Gynecologist")} className={menuCss("Gynecologist")}>Gynecologist</p>
        <p onClick={()=>navigate("/doctors/Dermatologist")} className={menuCss("Dermatologist")}>Dermatologist</p>
        <p onClick={()=>navigate("/doctors/Pediatricians")} className={menuCss("Pediatricians")}>Pediatrician</p>
        <p onClick={()=>navigate("/doctors/Neurologist")} className={menuCss("Neurologist")}>Neurology</p>
        <p onClick={()=>navigate("/doctors/Gastroenterologist")} className={menuCss("Gastroenterologist")}>Gastroenterologist</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 px-4 py-8">
        {filterDoc.map((item, pos) => (
          <div
            key={pos}
            onClick={() => navigate(`/appointment/${item._id}`)}
            className="border border-blue-200 rounded-xl overflow-hidden shadow-md cursor-pointer transform transition-transform duration-500 hover:-translate-y-2.5 bg-white"
          >
            <img
              className="w-full object-cover bg-blue-50"
              src={item.image}
              alt={item.name}
            />
            <div className="p-4 space-y-1">
              <div className="flex items-center gap-2 text-sm text-green-600">
                <span className="w-2 h-2 bg-green-500 rounded-full inline-block"></span>
                <span>Available</span>
              </div>
              <p className="font-semibold">{item.name}</p>
              <p className="text-gray-600 text-sm">{item.speciality}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Doctor;
