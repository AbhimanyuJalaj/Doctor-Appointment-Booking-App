import React from 'react'
import { useState } from 'react'

function Login() {
  const [state,setState] = useState('sign up')
  const [email,setEmail] = useState('')
  const [pass,setPass] = useState('')
  const [name,setName] = useState('')

  const onSubmit = async (event) =>{
    event.preventDefault()
  }



  return (
    <div>

      <form method="post" onSubmit={onSubmit} className='min-h-[80vh] flex items-center'>
        <div className='flex flex-col gap-3 m-auto items-start p-8 min-w-[340px] sm:min-w-96 border rounded-xl text-zinc-600 text-small shadow-lg '>
          <p className='text-2xl font-semibold'>   {state==="sign up" ? "Create Account" : "Login"}   </p>
          <p>Please {state==="sign up" ? "Create Account" : "Login"} to book an appointment</p>
          { state === "sign up" &&
          <div className='w-full'>
            <p>Full Name </p>
            <input className='border border-zic-300 rounded w-full p-2 mt-1' type="text" onChange={(e)=>setName(e.target.value)} value={name}/>
          </div>
          }
          <div className='w-full'>
            <p>Email </p>
            <input className='border border-zic-300 rounded w-full p-2 mt-1' type="email" onChange={(e)=>setEmail(e.target.value)} value={email}/>
          </div>
          <div className='w-full'>
            <p>PassWord</p>
            <input className='border border-zic-300 rounded w-full p-2 mt-1' type="password" onChange={(e)=>setPass(e.target.value)} value={pass}/>
          </div>
          <button className="bg-blue-600 text-white px-6 py-2 rounded-md shadow hover:bg-blue-700 transition duration-300">
                {state === "sign up" ? "Create Account" : "Login"}
          </button>
          {
              state === "sign up" ? (
                <p className="text-sm text-gray-600 mt-4">
                Already have an account?{" "}
                <span onClick={()=>setState('login')} className="text-blue-600 font-medium hover:underline cursor-pointer">
                Login
                </span>
                </p>
              ) : (
                <p className="text-sm text-gray-600 mt-4">
                Want to create a new account?{" "}
                <span onClick={()=>setState('sign up')} className="text-blue-600 font-medium hover:underline cursor-pointer">
                Sign Up
                </span>
                </p>
              )
            }

        </div>
        
      </form>
      
    </div>
  )
}

export default Login
