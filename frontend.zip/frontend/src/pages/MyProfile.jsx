import React, { useState } from 'react'
import { assets } from '../assets/assets'

function MyProfile() {
  const [userData, setUserData] = useState({
    name: "Abhimanyu Ji",
    image: assets.profile_pic,
    email: "suntero@gmail.com",
    phone: "+1 23 43467",
    address: {
      line1: "4572 Maple Grove Ln",
      line2: "Springfield, IL 62704"
    },
    gender: "Male",
    dob: "1991-03-17"
  })

  const [isEdit, setIsEdit] = useState(false)

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded-lg">
      <div className="flex items-center space-x-6">
        <img
          src={userData.image}
          alt="Profile"
          className="w-24 h-24 rounded-full border border-gray-300 object-cover"
        />
        <div>
          {isEdit ? (
            <input
              type="text"
              value={userData.name}
              onChange={e =>
                setUserData(prev => ({ ...prev, name: e.target.value }))
              }
              className="border px-3 py-2 rounded-md w-full"
            />
          ) : (
            <h2 className="text-2xl font-semibold">{userData.name}</h2>
          )}
        </div>
      </div>

      <hr className="my-6" />

      <div>
        <h3 className="text-xl font-medium mb-4">Contact Information</h3>

        <div className="flex gap-4 mb-2">
          <p className="font-medium w-24">Email:</p>
          <p>{userData.email}</p>
        </div>

        <div className="flex gap-4 mb-2">
          <p className="font-medium w-24">Phone:</p>
          {isEdit ? (
            <input
              type="text"
              value={userData.phone}
              onChange={e =>
                setUserData(prev => ({ ...prev, phone: e.target.value }))
              }
              className="border px-3 py-1 rounded-md"
            />
          ) : (
            <p>{userData.phone}</p>
          )}
        </div>

        <div className="flex gap-4 mb-4">
          <p className="font-medium w-24">Address:</p>
          {isEdit ? (
            <div className="flex flex-col space-y-2">
              <input
                type="text"
                value={userData.address.line1}
                onChange={e =>
                  setUserData(prev => ({
                    ...prev,
                    address: { ...prev.address, line1: e.target.value }
                  }))
                }
                className="border px-3 py-1 rounded-md"
              />
              <input
                type="text"
                value={userData.address.line2}
                onChange={e =>
                  setUserData(prev => ({
                    ...prev,
                    address: { ...prev.address, line2: e.target.value }
                  }))
                }
                className="border px-3 py-1 rounded-md"
              />
            </div>
          ) : (
            <div>
              <p>{userData.address.line1}</p>
              <p>{userData.address.line2}</p>
            </div>
          )}
        </div>
      </div>

      <div className="mt-6">
        <h3 className="text-xl font-medium mb-4">Basic Information</h3>

        <div className="flex gap-4 mb-2">
          <p className="font-medium w-24">Gender:</p>
          {isEdit ? (
            <select
              value={userData.gender}
              onChange={e =>
                setUserData(prev => ({ ...prev, gender: e.target.value }))
              }
              className="border px-3 py-1 rounded-md"
            >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          ) : (
            <p>{userData.gender}</p>
          )}
        </div>

        <div className="flex gap-4 mb-4">
          <p className="font-medium w-24">Birth Date:</p>
          {isEdit ? (
            <input
              type="date"
              value={userData.dob}
              onChange={e =>
                setUserData(prev => ({ ...prev, dob: e.target.value }))
              }
              className="border px-3 py-1 rounded-md"
            />
          ) : (
            <p>{userData.dob}</p>
          )}
        </div>

        <div className="mt-4">
          {isEdit ? (
            <button
              onClick={() => setIsEdit(false)}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition"
            >
              Save Information
            </button>
          ) : (
            <button
              onClick={() => setIsEdit(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition"
            >
              Edit
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

export default MyProfile
