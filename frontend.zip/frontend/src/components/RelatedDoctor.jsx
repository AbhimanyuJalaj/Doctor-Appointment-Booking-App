import React, { useState, useEffect, useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';

const RelatedDoctor = ({ docId, speciality }) => {
  const { doctors } = useContext(AppContext);
  const [relDoc, setRelDoc] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRelatedDoctors = async () => {
      if (doctors.length > 0 && speciality) {
        const filteredDoctors = doctors.filter(doc => doc.speciality === speciality);
        const relatedDoctors = filteredDoctors.filter(doc => doc._id !== docId);
        setRelDoc(relatedDoctors);
      }
    };

    fetchRelatedDoctors();
  }, [doctors, docId, speciality]);

  return (
    <div className="px-4 sm:px-0 py-6">
      <h2 className="text-lg sm:text-2xl font-semibold text-gray-800 mb-2">
        Related Doctors
      </h2>
      <p className="text-sm text-gray-600 mb-4">
        Browse more {speciality}
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {relDoc.slice(0, 12).map((item, index) => (
          <div
            key={index}
            onClick={() => {
              navigate(`/appointment/${item._id}`);
              window.scrollTo(0, 0);
            }}
            className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-transform duration-300 hover:-translate-y-1"
          >
            <img
              className="w-full h-48 object-cover bg-blue-50"
              src={item.image}
              alt={item.name}
            />
            <div className="p-4 space-y-1">
              <div className="flex items-center gap-2 text-sm text-green-600">
                <span className="w-2 h-2 bg-green-500 rounded-full inline-block"></span>
                <span>Available</span>
              </div>
              <p className="font-semibold text-gray-800 text-base">{item.name}</p>
              <p className="text-gray-600 text-sm">{item.speciality}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RelatedDoctor;
