import React from 'react';
import { assets } from '../assets/assets';

function Header() {
  return (
    <div className='flex flex-col h-auto md:flex-row flex-wrap bg-blue-600 md:px-10 lg:px-20'>

      {/* LEFT */}
      <div className='flex flex-col items-start justify-center gap-6 py-10 m-auto md:w-1/2 md:py-[10vw]'>

        <p className='ml-1 text-3xl md:text-4xl lg:text-5xl text-white font-semibold leading-tight'>
          Book Appointment <br /> with trusted doctors
        </p>

        <div className='flex items-center gap-4'>
            
          <img src={assets.group_profiles} alt="Specialist Profiles" className='ml-3 w-28' />
          <p className='text-white text-sm'>
            Connect with specialists across multiple domains, <br className='hidden sm:block' /> from pediatrics to neurology.
          </p>
        </div>

        <a href="#speciality" className='ml-3 flex items-center gap-2 bg-white text-blue font-medium mt-4 hover:underline px-8 py-3 rounded-full'>
          Book Appointment <img src={assets.arrow_icon} alt="Arrow Icon" className='w-3' />
        </a>
      </div>

      {/* RIGHT */}
      <div className='flex items-end justify-center md:w-1/2 mt-0 md:mt-0'>
        <img 
            src={assets.header_img} 
            alt="Header Visual" 
            className='w-full md:absolute h-auto flex-bottom max-w-md rounded-lg' 
        />
      </div>

    </div>
  );
}

export default Header;
