import React from 'react';
import { assets } from '../assets/assets';
import { useNavigate } from 'react-router-dom';

function Footer() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col sm:grid grid-cols-[3fr_1fr_1fr] gap-14 my-10 mt-40 text-sm px-6">
      {/* LEFT */}
      <div>
        <img src={assets.logo} alt="Prescripto Logo" className="mb-5 w-40" />
        <p className="w-full text-justify md:-2/3 text-gray-600 leading-6">
          Welcome to <strong>Prescripto</strong>, your trusted platform for connecting with qualified doctors and receiving professional medical prescriptions online. We make healthcare more accessible by offering convenient, secure, and reliable consultations from certified professionals—all from the comfort of your home.
        </p>
      </div>

      {/* CENTER */}
      <div>
        <p className="font-semibold mb-2">COMPANY</p>
        <ul className="flex flex-col gap-2 space-y-1 text-gray-700">
          <li onClick={()=>navigate("/about")} className='cursor-pointer'>About Us</li>
          <li onClick={()=>{navigate("/"), scrollTo(0,0)}} className='cursor-pointer'>Home</li>
          <li onClick={()=>navigate("/contactus")} className='cursor-pointer'>Contact Us</li>
          <li>Privacy Policy</li>
        </ul>
      </div>

      {/* RIGHT */}
      <div>
        <p className="font-semibold mb-2">GET IN TOUCH</p>
        <ul className="flex flex-col gap-2 space-y-1 text-gray-700">
          <li>+1-234-567-8910</li>
          <li>prescripto@dev.com</li>
        </ul>
      </div>

      {/* COPYRIGHT */}
      <div className="col-span-full text-center pt-10 text-xs text-gray-500">
        <p>© 2024 Prescripto – All Rights Reserved</p>
      </div>
    </div>
  );
}

export default Footer;
