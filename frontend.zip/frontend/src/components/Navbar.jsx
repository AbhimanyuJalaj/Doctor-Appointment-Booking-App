import React, { useState } from 'react';
import { assets } from '../assets/assets';
import { NavLink, useNavigate } from 'react-router-dom';
import { FaBars, FaTimes } from 'react-icons/fa';

function Navbar() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [token, setToken] = useState(true);

  const handleNavigate = (path) => {
    navigate(path);
    setMenuOpen(false);
  };

  return (
    <div className="relative">
      <div className="flex items-center justify-between py-4 px-4 md:px-8 border-b border-b-gray-400">
        {/* Logo */}
        <img
          onClick={() => handleNavigate('/')}
          src={assets.logo}
          alt="Logo"
          className="w-32 md:w-44 cursor-pointer"
        />

        {/* Desktop Nav */}
        <ul className="hidden md:flex items-center gap-6 font-medium text-sm">
          <li><NavLink to="/" className="hover:text-primary">HOME</NavLink></li>
          <li><NavLink to="/doctors" className="hover:text-primary">ALL DOCTORS</NavLink></li>
          <li><NavLink to="/about" className="hover:text-primary">ABOUT</NavLink></li>
          <li><NavLink to="/contact" className="hover:text-primary">CONTACT</NavLink></li>
        </ul>

        {/**Small login ICON */}

      <div className="md:flex md:flex-end">
        {token ? (
          <div className="flex items-center gap-2 cursor-pointer group relative">
            <img className="w-8 rounded-full" src={assets.profile_pic} alt="Profile" />
            <img className="w-2.5" src={assets.dropdown_icon} alt="Dropdown" />
            <div className="absolute top-0 right-0 pt-14 text-base font-medium text-gray-600 z-20 hidden group-hover:block">
              <div className="min-w-48 bg-stone-100 rounded flex flex-col gap-4 p-4">
                <p onClick={() => navigate('/my-profile')} className="hover:text-black cursor-pointer">My Profile</p>
                <p onClick={() => navigate('/my-appointment')} className="hover:text-black cursor-pointer">My Appointment</p>
                <p onClick={() => setToken(false)} className="hover:text-black cursor-pointer">Logout</p>
              </div>
            </div>
          </div>
        ) : (
          <button onClick={() => handleNavigate('/login')} className="bg-blue-500 text-white font-bold px-6 py-2 rounded-full">
            Create Account
          </button>
        )}
      </div>

      {/** Mobile Menu */}
      <div className='flex md:justify-end md:hidden'>
      {menuOpen && (
        <div className="md:items-end md:hidden bg-white shadow-md w-full absolute left-0 top-full z-50">
          <ul className="flex flex-col items-center gap-4 py-4 font-medium text-sm">
            <li><NavLink to="/" onClick={() => handleNavigate('/')}>HOME</NavLink></li>
            <li><NavLink to="/doctors" onClick={()=> handleNavigate('/doctors')}>ALL DOCTORS</NavLink></li>
            <li><NavLink to="/about" onClick={()=> handleNavigate('/about')}>ABOUT</NavLink></li>
            <li><NavLink to="/contact" onClick={()=> handleNavigate('/contact')}>CONTACT</NavLink></li>
          </ul>
        </div>
      )}

      {/* Mobile Hamburger Icon */}
        <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden">
          {menuOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
        </button>

      </div>


      

      </div>

      
        
    </div>
  );


}

export default Navbar;



/*



*/
