import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  plugins: [react(),tailwindcss()],
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `:root { --color-primary: #5f6fff; }`
      }
    }
  },
  theme: {
    extend: {
      gridTemplateColumns: {
        auto: 'repeat(auto-fill, minmax(200px, 1fr))'
      }
    }
  }
})





